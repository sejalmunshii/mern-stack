import React from 'react'

function CompoMenu() {
 return (
    <div className="container">
      <h2 className="fw-bold mb-3">Component Menu</h2>

     
    </div>
  );
}

export default CompoMenu;
