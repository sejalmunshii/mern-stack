import React from 'react'

function Intro() {
  return (
    <>
    <h1>Intro</h1>
    </>
  )
}

export default Intro;