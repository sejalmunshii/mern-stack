import React from 'react'
import { NavLink, Outlet } from 'react-router';

function JsxMenu() {
 return (
    <div className="container">
      <h2 className="fw-bold mb-3">JSX menu</h2>

     
    </div>
  );
}

export default JsxMenu;
