import React from 'react'

function RouterCompo() {
  return (
    <>
      <h2>Learning React Router</h2> 
    </>
  )
}

export default RouterCompo
