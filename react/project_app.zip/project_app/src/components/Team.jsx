import React from 'react'

function Team() {
  return (
    <>
        <h2>I'm Team</h2> 
    </>
  )
}

export default Team
